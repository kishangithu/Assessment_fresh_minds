import {sortCarModelsAlphabetically} from '../project-root/problem3.js';
import inventory from '../inventory.js';


const sortedModels = sortCarModelsAlphabetically(inventory);
console.log(sortedModels);
