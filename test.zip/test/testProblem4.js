import {getAllCarYears} from '../project-root/problem4.js';
import inventory from '../inventory.js';

const carYears = getAllCarYears(inventory);
console.log(carYears);
