import {countCarsOlderThan2000} from '../project-root/problem5.js';
import inventory from '../inventory.js';
const olderCarsCount = countCarsOlderThan2000(inventory);
console.log(`Number of cars older than 2000: ${olderCarsCount}`);
