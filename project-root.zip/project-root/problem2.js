export function findLastCar(inventory) {
    return inventory[inventory.length - 1];
}
